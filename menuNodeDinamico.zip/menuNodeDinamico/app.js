require('colors');

const {guardarDB} = require('./helpers/guardarArchivo');
const {inquirerMenu, pausa, leerInput} = require('./helpers/inquirer');
const Tareas = require('./models/tareas');

const main = async()=> {
    let opt = '';
    const tareas = new Tareas();
    
    do {
        opt = await inquirerMenu();
        tareas._listado[tarea.id] = tarea;
        switch(opt){
            case '1':
                const desc = await leerInput('Descripcion: ');
                tareas.crearTarea(desc);
                break;
            /*case '2':
                break;
            default:
                break;*/
        }
        guardarDB(tareas.listadoArr);
        await pausa();
        
    } while (opt != '0');
}

main();