const { resolve } = require('path');

require('colors');

const mostrarMenu = ()=> {
    return new Promise(resolve =>{
        console.clear();
        console.log("========================");
        console.log("Seleccione una opcion");
        console.log("========================");

        console.log(`${'1. Crear Tareas'.red}`);
        console.log("2. Listar Tareas");
        console.log("3. Listar Tareas Completadas");
        console.log("4. Listar Tareas Pendientes");
        console.log("5. Completar Tareas");
        console.log("6. Borrar Tareas");
        console.log("0. Salir");

        const readline = require('readline').createInterface({
            input: process.stdin,
            output: process.stdout
        });

        readline.question('Seleccione una opcion: ', (opt)=>{
            readline.close();
            resolve(opt);
        })
    });
}

const pausa = () => {
    return new Promise (resolve =>{
        const readline = require('readline').createInterface({
            input: process.stdin,
            output: process.stdout
        });
    
        readline.question('Presione Enter para elegir', (opt)=>{
            readline.close();
            resolve();
        })
    });
}


module.exports = {
    mostrarMenu,
    pausa
}
