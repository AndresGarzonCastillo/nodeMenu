require('colors');
const inquirer = require('inquirer');
//const prompt = inquirer.createPromptModule();

const preguntas =[
    {
        type: 'list',
        name: 'opcion',
        message: 'que desea hacer',
        choices: [
            {
            value: '1',
            name: `${'1'.red}. Crear Tareas`
        },
        {
            value: '2',
            name: `${'2'.red}. Listar Tareas`
        },
        {
            value: '3',
            name: `${'3'.red}. Listar Tareas Completadas`
        },
        {
            value: '4',
            name: `${'4'.red}. Listar Tareas Pendientes`
        },
        {
            value: '5',
            name: `${'5'.red}. Completar Tareas`
        },
        {
            value: '6',
            name: `${'6'.red}. Borrar Tareas`
        },
        {
            value: '0',
            name: `${'0'.red}. Salir`
        },
        ]
    }
]

const inquirerMenu = async () => {
    console.clear();
    console.log("========================");
    console.log("Seleccione una opcion".blue);
    console.log("========================");
    /*const {opcion} = await inquirer.prompt(preguntas);
    return opcion;
    let otp = '';
    const {otp} = await inquirer.prompt(preguntas).then(data => {
        otp = data['opcion']
    })
    return otp;*/
}

const pausa = async () => {
    const question = [
        {
            type: 'input',
            name: 'enter',
            message: `\nPresione ${'Enter'.gray} para continuar\n`
        }
    ]

    await inquirer.prompt(question);
    /*let pau = '';
    console.log('\n');
    await inquirer.prompt(question).then(data => {
        pau = data['message']
    });

    return pau;*/
}

const leerInput = async (message) => {
    const question = [
        {
            type: 'input',
            name: 'desc',
            message,
            validate(value){
                if(value.length === 0){
                    return 'Por Favor elige una opcion';
                }
                return true;
            }
        }
    ];

    /*let leer = '';
    const {desc} = await inquirer.prompt(question).then(data => {
        leer = data['desc'];
    })
    return leer;*/
}

module.exports = {
    inquirerMenu,
    pausa,
    leerInput
}